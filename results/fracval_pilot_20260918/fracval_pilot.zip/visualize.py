"""Render selected geometries as exact orthographic sphere silhouettes; write VTP."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from matplotlib.collections import PatchCollection
root=Path(__file__).parent
selection=json.loads((root/'selected.json').read_text())
fig,axes=plt.subplots(1,len(selection),figsize=(14,5.5),layout='constrained')
for ax,row in zip(np.atleast_1d(axes),selection):
 name=row['label'];data=np.loadtxt(root/name/'particles.csv',delimiter=',',skiprows=1)
 xyz=data[:,:3];radius=data[:,3];xyz-=xyz.mean(0)
 _,_,vt=np.linalg.svd(xyz,full_matrices=False);q=xyz@vt.T
 order=np.argsort(q[:,2]);z=q[:,2];norm=(z-z.min())/max(np.ptp(z),1e-12)
 patches=[Circle(q[i,:2],radius[i]) for i in order]
 collection=PatchCollection(patches,facecolors=plt.cm.Blues(.4+.45*norm[order]),edgecolors='#17324d',linewidths=.18)
 ax.add_collection(collection)
 lo=(q[:,:2]-radius[:,None]).min(0);hi=(q[:,:2]+radius[:,None]).max(0)
 margin=.07*max(hi-lo);ax.set_xlim(lo[0]-margin,hi[0]+margin);ax.set_ylim(lo[1]-margin,hi[1]+margin);ax.set_aspect('equal')
 ax.set_xlabel('x / particle diameter');ax.set_ylabel('y / particle diameter')
 ax.set_title(f"Target {row['target_box_dimension']:.1f}; measured {row['box_dimension']:.3f}\nN = {len(data):,}; hull porosity = {row['hull_porosity']:.3f}")
 # SI coordinates with d = 1 um. ParaView: Glyph > Sphere, scale by radius, factor 2.
 points=' '.join(f'{v*1e-6:.16g}' for v in xyz.ravel());radii=' '.join(f'{v*1e-6:.16g}' for v in radius)
 n=len(data);indices=' '.join(map(str,range(n)));offsets=' '.join(map(str,range(1,n+1)))
 (root/name/'particles.vtp').write_text(f'''<?xml version="1.0"?>
<VTKFile type="PolyData" version="0.1" byte_order="LittleEndian"><PolyData><Piece NumberOfPoints="{n}" NumberOfVerts="{n}" NumberOfLines="0" NumberOfStrips="0" NumberOfPolys="0"><PointData Scalars="radius"><DataArray type="Float64" Name="radius" format="ascii">{radii}</DataArray></PointData><Points><DataArray type="Float64" NumberOfComponents="3" format="ascii">{points}</DataArray></Points><Verts><DataArray type="Int64" Name="connectivity" format="ascii">{indices}</DataArray><DataArray type="Int64" Name="offsets" format="ascii">{offsets}</DataArray></Verts></Piece></PolyData></VTKFile>''')
fig.suptitle('Original FracVAL: measured box-counting pilot\nIndependent panel scales; orthographic projection; no DEM relaxation',fontsize=14)
fig.savefig(root/'agglomerates.png',dpi=180)
plt.close(fig)
fig,axes=plt.subplots(1,len(selection),figsize=(14,4.5),layout='constrained')
for ax,row in zip(np.atleast_1d(axes),selection):
 curves=np.genfromtxt(root/row['label']/'box_curves.csv',delimiter=',',names=True)
 for orient in [0,1,2]:
  for shift in [0,.5]:
   a=curves[(curves['orientation']==orient)&(curves['shift']==shift)]
   ax.plot(np.log10(1/a['box_size_over_d']),np.log10(a['occupied']),'.-',alpha=.65)
 ax.set_title(f"Measured Dbox = {row['box_dimension']:.3f}\nGrid SD {row['box_grid_sd']:.3f}; span {row['box_scale_span_decades']:.2f} decades")
 ax.set_xlabel('log10(d / box size)');ax.set_ylabel('log10(occupied boxes)');ax.grid(alpha=.2)
fig.suptitle('Unchanged estimator: eight box sizes, three orientations, two grid shifts')
fig.savefig(root/'box_counting.png',dpi=180)
